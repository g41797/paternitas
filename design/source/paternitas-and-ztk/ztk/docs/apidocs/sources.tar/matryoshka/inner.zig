// SPDX-FileCopyrightText: Copyright (c) 2026 g41797
// SPDX-License-Identifier: MIT

//! The two small types everything else is written against.
//!
//! - `Inner` is the part you put inside your own struct.
//! - `Slot` is the place where one outer may be, or may not.
//! - The mailbox and the pool see an `*Inner` and nothing else.
//!
//! An outer's id is a pointer to its one `OuterInfo`. Ids are compared by
//! address, so an id says what a thing is, never which one it is.
//!
//! Examples:
//! https://g41797.github.io/matryoshka-ztk/examples/inner/
const _doc_stub = void;

/// What one outer type is, written once at compile time.
///
/// - `name` is the type's own name. It goes into panic text.
/// - `inner_offset` is where the `Inner` field sits in the outer.
///
/// Built by the helper and by nothing else. One per outer type, `const`, so
/// it lives in read-only memory.
pub const OuterInfo = struct {
    name: []const u8,
    inner_offset: usize,
};

/// An outer's id: the address of its `OuterInfo`.
///
/// Two outers of one type answer the same address. Two types answer two
/// addresses.
pub const OuterId = *const OuterInfo;

/// The id of an outer that was never stamped.
///
/// It is a real `OuterInfo`, not a sentinel. So `id` is never undefined and
/// reading it is defined.
///
/// - Its name reads `<unstamped>`.
/// - Its offset is zero, so a missed check yields the inner's own address
///   rather than a wild pointer.
pub const UNSTAMPED: OuterId = &unstamped;

const unstamped: OuterInfo = .{
    .name = "<unstamped>",
    .inner_offset = 0,
};

/// Embedded in every outer. Two fields, both for the toolkit.
///
/// The chain link is `node.next`:
///
/// - the next inner on the chain
/// - the inner itself when it is the last one on a chain
/// - null when the outer is on no chain
///
/// So the link test is exact, and it costs one compare. A chain of one is
/// seen, which a null-or-not test cannot do.
///
/// `id` is written once, by the helper's stamp, and never again.
///
/// The border with `std` — MUST:
///
/// - `node` is `std.SinglyLinkedList.Node`, so an outer may go onto a plain
///   `std.SinglyLinkedList`.
/// - It leaves this toolkit's `Queue` first. One item, one chain.
/// - The two chains disagree on the last link: ours points at itself, std's
///   is null. One field cannot hold both conventions at once.
/// - `std` does not clear the link it hands back. An item returning from a
///   std list arrives still pointing into it, and the crossing back refuses
///   it.
pub const Inner = struct {
    node: std.SinglyLinkedList.Node = .{},
    id: OuterId = UNSTAMPED,
};

/// Where one outer may be, or may not.
///
/// Empty means the caller has nothing. Full means the caller has that outer.
/// A call that takes the outer leaves the Slot empty, with no line left for
/// the caller to write.
pub const Slot = ?*Inner;

/// One outer, type-erased, for a container the toolkit does not own.
///
/// - `ptr` is the address of the outer, not of its inner.
/// - `id` says what the outer is, and carries the offset to its inner.
/// - `ptr` is null exactly when `id` is `UNSTAMPED`. Empty is that one state:
///   the default, and what `reset` writes back.
///
/// Read `ptr` and `id`, and write them only through `set` and `reset`.
///
/// MUST:
///
/// - An `AnyOuter` is moved, never copied. Two copies are two owners.
/// - A container closed while it still holds `AnyOuter` values leaks them, so
///   the caller drains it first.
/// - A raw cast of `ptr` loses alignment. Read it with `fromAny`.
pub const AnyOuter = struct {
    ptr: ?*anyopaque = null,
    id: OuterId = UNSTAMPED,

    pub inline fn isEmpty(self: *const AnyOuter) bool {
        return self.ptr == null;
    }

    /// Fills an empty `AnyOuter`. Refuses a full one and a half-set pair.
    pub inline fn set(self: *AnyOuter, ptr: *anyopaque, id: OuterId) void {
        check(self.isEmpty(), "never overwrite a full AnyOuter");
        check(id != UNSTAMPED, "an AnyOuter holds a stamped outer");
        self.* = .{ .ptr = ptr, .id = id };
    }

    pub inline fn reset(self: *AnyOuter) void {
        self.* = .{};
    }
};

/// True when the outer is on a chain.
///
/// Exact. The only item of a chain points at itself, so it reads as linked.
pub inline fn isLinked(inner: *const Inner) bool {
    return inner.node.next != null;
}

/// True when the outer was stamped.
pub inline fn isStamped(inner: *const Inner) bool {
    return inner.id != UNSTAMPED;
}

/// The address of the outer this inner sits in, without knowing its type.
///
/// This is what `inner_offset` is for. The result agrees with the compile-time
/// crossing the helper does.
///
/// Refuses an unstamped inner: check before you compute.
pub inline fn outerAddr(inner: *const Inner) *anyopaque {
    check(isStamped(inner), "the outer was never stamped: make it with create, or stamp it once");
    const bytes: [*]u8 = @ptrCast(@constCast(inner));
    return @ptrCast(bytes - inner.id.inner_offset);
}

/// The inner holding this std node.
pub inline fn ofNode(node: *std.SinglyLinkedList.Node) *Inner {
    return @fieldParentPtr("node", node);
}

/// Clears the chain link.
///
/// Called for the caller by every removal. Nothing hands back a linked item.
pub inline fn unlink(inner: *Inner) void {
    inner.node.next = null;
}

const check = @import("internal/check.zig").check;
const std = @import("std");
