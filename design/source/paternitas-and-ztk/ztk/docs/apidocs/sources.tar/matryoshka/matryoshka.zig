// SPDX-FileCopyrightText: Copyright (c) 2026 g41797
// SPDX-License-Identifier: MIT

//! A toolkit for Zig 0.16: items move between holders, and are created and
//! released.
//!
//! This module root is the whole public surface. Nothing else is importable.
//!
//! Three layers, each optional above the first:
//!
//! - the core — an outer, its inner, the id, the helper, the queue
//! - the mailbox — items move from one context to another
//! - the pool — items are kept and handed out again
//!
//! Examples:
//! https://g41797.github.io/matryoshka-ztk/examples/flow/
const _doc_stub = void;

/// What one outer type is.
pub const OuterInfo = inner.OuterInfo;

/// An outer's id: the address of its `OuterInfo`.
pub const OuterId = inner.OuterId;

/// The id of an outer that was never stamped.
pub const UNSTAMPED = inner.UNSTAMPED;

/// Embedded in every outer.
pub const Inner = inner.Inner;

/// Where one outer may be, or may not.
pub const Slot = inner.Slot;

/// One outer, type-erased, for a container the toolkit does not own.
pub const AnyOuter = inner.AnyOuter;

/// True when the outer is on a chain.
pub const isLinked = inner.isLinked;

/// True when the outer was stamped.
pub const isStamped = inner.isStamped;

/// The address of the outer, without knowing its type.
pub const outerAddr = inner.outerAddr;

/// The inner holding a std node, for an item coming back from a std list.
pub const ofNode = inner.ofNode;

/// A first in, first out chain of outers.
pub const Queue = queue.Queue;

/// Generates the runtime type support for one outer type.
pub const OuterHelper = helper.OuterHelper;

/// Takes the bare inner out of a Slot, for a container of your own.
pub const takeFromSlot = helper.takeFromSlot;

/// Puts a bare inner back into an empty Slot.
pub const fillSlot = helper.fillSlot;

/// Moves the outer from a Slot into an empty `AnyOuter`.
pub const slotToAny = helper.slotToAny;

/// Moves the outer from an `AnyOuter` into an empty Slot.
pub const anyToSlot = helper.anyToSlot;

/// A queue between contexts. Itself an outer.
pub const Mbox = mbox.Mbox;

/// Makes a mailbox and puts it in the Slot.
pub const newMbox = mbox.new;

/// Every outcome of a receive, for `Io.Select` and `Io.Group`.
pub const receiveResult = mbox.receiveResult;

/// Every outcome of a waiting get, for `Io.Select` and `Io.Group`.
pub const getWaitResult = pool.getWaitResult;

/// Keeps used outers so they can be used again. Itself an outer.
pub const Pool = pool.Pool;

/// Makes a pool and puts it in the Slot.
pub const newPool = pool.new;

/// The toolkit's version.
pub const VERSION = "0.1.0";

const helper = @import("helper.zig");
const inner = @import("inner.zig");
const mbox = @import("mbox.zig");
const pool = @import("pool.zig");
const queue = @import("queue.zig");
