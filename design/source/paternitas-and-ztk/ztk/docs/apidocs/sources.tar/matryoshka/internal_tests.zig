// SPDX-FileCopyrightText: Copyright (c) 2026 g41797
// SPDX-License-Identifier: MIT

//! The root of the tests that live inside `src/`.
//!
//! An internal file is not reachable from the module root, so the `tests/`
//! tree — which meets the toolkit through `@import("matryoshka")` — cannot
//! see it. This is the other root `zig build test` runs, and it exists so an
//! internal type is tested directly rather than only through the container
//! that uses it.
//!
//! It is not part of the toolkit's surface and is imported by nothing.

comptime {
    _ = @import("internal/stack.zig");
}
